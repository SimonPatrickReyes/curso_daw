import { createApp } from 'vue'
import App from './App.vue'


import './assets/animations.css'
import './assets/styles.css'


createApp(App).mount('#app')
